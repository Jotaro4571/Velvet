@echo off
cd /d "%~dp0"
where py >nul 2>&1 && (
  py -3 Velvet.pyw
  if errorlevel 1 pause
  exit /b
)
where python >nul 2>&1 && (
  python Velvet.pyw
  if errorlevel 1 pause
  exit /b
)
echo Python не найден. Установите Python 3 с python.org и отметьте "Add python.exe to PATH".
pause
