#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VELVET 2.1.2 — лаунчер 18+.

Исправление запуска: папка программы задаётся до файла обновлений.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import smtplib
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
import zipfile
from email.message import EmailMessage
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

VERSION = "2.2.0"
ADMIN_KEY = "VELVET-1-ADMIN"
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DOWNLOADS = ROOT / "downloads"
GAMES = ROOT / "games"
AVATARS = DATA / "avatars"
ICONS = DATA / "icons"
BACKUPS = DATA / "backups"
MODS = DATA / "mods"
SAVE_BACKUPS = DATA / "save-backups"
ASSETS = ROOT / "assets"
STORE_PATH = DATA / "store.json"
UPDATE_FILE = ROOT / "update_url.txt"
for folder in (DATA, DOWNLOADS, GAMES, AVATARS, ICONS, BACKUPS, MODS, SAVE_BACKUPS):
    folder.mkdir(parents=True, exist_ok=True)

BG, BG2, CARD, LINE = "#0e0b12", "#16121c", "#1c1724", "#2c2633"
TEXT, MUTED, FAINT, ROSE, GOLD = "#f6f1ea", "#a39890", "#6e655e", "#ff2d6a", "#e7b15a"

ACHIEVEMENTS = [
    ("hello", "Свой аккаунт", "Почта подтверждена"),
    ("face", "Лицо", "Поставлена своя аватарка"),
    ("first", "Первый запуск", "Запущена первая игра"),
    ("shelf", "Своя полка", "В библиотеке 3 игры"),
    ("collector", "Коллекционер", "В библиотеке 5 игр"),
    ("marathon", "Марафон", "2 часа в одной игре"),
    ("gamer", "Игроман", "10 часов по аккаунту"),
    ("store", "Легальный путь", "Открыта веб-витрина"),
    ("modder", "Моддер", "К игре добавлен мод"),
    ("archivist", "Архивариус", "Сохранение открыто в редакторе"),
    ("safe", "Сейф", "Сработало автосохранение профиля"),
    ("horny_start", "Стив в кубах", "Hornycraft добавлен в библиотеку"),
    ("horny_night", "Ночь в Hornycraft", "1 час в Hornycraft"),
    ("lona_start", "Дорога Лоны", "LonaRPG добавлена в библиотеку"),
    ("lona_road", "Долгий путь", "3 часа в LonaRPG"),
    ("encode_start", "Первый трек", "Encode Encore добавлен в библиотеку"),
    ("encode_listen", "На повторе", "1 час в Encode Encore"),
]

STORES = [
    ("Steam — взрослые игры", "Витрина с возрастным замком.", "https://store.steampowered.com/tags/en/Sexual+Content/"),
    ("itch.io NSFW", "Инди и демо от авторов.", "https://itch.io/games/tag-nsfw"),
    ("Nutaku", "Браузерные и PC-игры 18+.", "https://www.nutaku.net/"),
    ("Patreon авторов", "Свежие сборки у авторов.", "https://www.patreon.com/"),
    ("Summertime Saga", "Официальный сайт бесплатной песочницы.", "https://www.summertimesaga.com/"),
    ("Being a DIK", "Сезон 1 в Steam.", "https://store.steampowered.com/app/1126320/Being_a_DIK__Season_1/"),
]

GAME_MARKS = (
    ("horny", "hornycraft", "horny_start", "horny_night", 3600),
    ("lona", "lonarpg", "lona_start", "lona_road", 3 * 3600),
    ("encode", "encode encore", "encode_start", "encode_listen", 3600),
)


def version_key(value: str) -> tuple:
    parts = []
    for piece in re.split(r"[^\d]+", value or ""):
        if piece.isdigit():
            parts.append(int(piece))
    return tuple(parts) or (0,)


def update_url() -> str:
    if not UPDATE_FILE.exists():
        return ""
    for line in UPDATE_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            return line
    return ""


def fetch_release(url: str) -> dict:
    req = Request(url, headers={"User-Agent": f"VelvetLauncher/{VERSION}"})
    with urlopen(req, timeout=12) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    if not isinstance(payload, dict) or not payload.get("version"):
        raise ValueError("В манифесте нет номера версии")
    return payload


def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M")


def fmt_time(seconds: int) -> str:
    seconds = int(seconds or 0)
    if seconds < 60:
        return "меньше минуты" if seconds else "0 ч"
    hours, mins = divmod(seconds // 60, 60)
    return f"{hours} ч {mins} мин" if hours else f"{mins} мин"


def atomic_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_store() -> dict:
    if not STORE_PATH.exists():
        store = {"users": {}, "pending": {}, "mailbox": {}, "settings": {}, "session": {}}
        atomic_write(STORE_PATH, store)
        return store
    try:
        store = json.loads(STORE_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        store = {}
    store.setdefault("users", {})
    store.setdefault("pending", {})
    store.setdefault("mailbox", {})
    store.setdefault("settings", {})
    store.setdefault("session", {})
    return store


def hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()


def nick_key(name: str) -> str:
    return name.casefold()


def launch_path(path: str) -> subprocess.Popen:
    target = Path(path).expanduser()
    if not target.exists():
        raise FileNotFoundError(f"Файл не найден:\n{target}")
    if sys.platform == "darwin":
        return subprocess.Popen(["open", str(target)])
    if sys.platform != "win32" and (target.is_dir() or not os.access(target, os.X_OK)):
        return subprocess.Popen(["xdg-open", str(target)])
    return subprocess.Popen([str(target)], cwd=str(target.parent))


def open_folder(path: str) -> None:
    target = Path(path).expanduser()
    folder = target if target.is_dir() else target.parent
    if not folder.exists():
        raise FileNotFoundError(f"Папка не найдена:\n{folder}")
    if sys.platform == "win32":
        os.startfile(str(folder))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(folder)])
    else:
        subprocess.Popen(["xdg-open", str(folder)])


def renpy_save_dir(title: str) -> Path | None:
    base = os.environ.get("APPDATA")
    if not base:
        return None
    folder = Path(base) / "RenPy"
    if not folder.exists():
        return None
    key = re.sub(r"[^a-z0-9]", "", title.casefold())
    for child in folder.iterdir():
        if key and key in re.sub(r"[^a-z0-9]", "", child.name.casefold()):
            return child
    return None


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"VELVET {VERSION}")
        self.geometry("1120x740")
        self.minsize(920, 600)
        self.configure(bg=BG)
        self.store = load_store()
        self.user = None
        self.view = "library"
        self.filter = "все"
        self.query = tk.StringVar()
        self.status = tk.StringVar(value=f"Velvet {VERSION}")
        self.images: dict[str, tk.PhotoImage] = {}
        self.jobs: dict[str, dict] = {}
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._style()
        self._icon()
        self.shell = tk.Frame(self, bg=BG)
        self.shell.pack(fill="both", expand=True)
        name = self.store.get("session", {}).get("username")
        account = self.store["users"].get(name) if name else None
        if account and account.get("age_ok") and account.get("email_ok"):
            account["username"] = name
            self.user = account
            self.show_main()
        else:
            self.show_auth()

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Velvet.Horizontal.TProgressbar", troughcolor="#2a2430", background=ROSE, bordercolor=BG, lightcolor=ROSE, darkcolor=ROSE)

    def _icon(self) -> None:
        png, ico = ASSETS / "icon.png", ASSETS / "icon.ico"
        if png.exists():
            try:
                self.images["app"] = tk.PhotoImage(file=str(png))
                self.iconphoto(True, self.images["app"])
            except tk.TclError:
                pass
        if ico.exists():
            try:
                self.iconbitmap(str(ico))
            except tk.TclError:
                pass

    def thumb(self, path: str, key: str, size: int = 64) -> tk.PhotoImage | None:
        file = Path(path)
        if not file.exists():
            return None
        cache = f"{key}-{size}"
        if cache in self.images:
            return self.images[cache]
        try:
            img = tk.PhotoImage(file=str(file))
        except tk.TclError:
            return None
        factor = max(1, max(img.width(), img.height()) // size)
        if factor > 1:
            img = img.subsample(factor, factor)
        self.images[cache] = img
        return img

    def clear(self) -> None:
        for child in self.shell.winfo_children():
            child.destroy()

    def save_store(self) -> None:
        if self.user:
            name = self.user["username"]
            stored = dict(self.user)
            stored.pop("username", None)
            self.store["users"][name] = stored
        atomic_write(STORE_PATH, self.store)

    def backup(self) -> None:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        target = BACKUPS / f"velvet-{stamp}.json"
        shutil.copyfile(STORE_PATH, target)
        latest = BACKUPS / "latest.json"
        shutil.copyfile(STORE_PATH, latest)
        old = sorted(BACKUPS.glob("velvet-*.json"))
        for extra in old[:-8]:
            extra.unlink(missing_ok=True)

    def on_close(self) -> None:
        self.save_store()
        self.backup()
        if self.user:
            self.unlock("safe", quiet=True)
            self.save_store()
        self.destroy()

    def show_auth(self) -> None:
        self.clear()
        wrap = tk.Frame(self.shell, bg=BG)
        wrap.pack(fill="both", expand=True)
        card = tk.Frame(wrap, bg=CARD, highlightbackground=LINE, highlightthickness=1, padx=28, pady=18)
        card.place(relx=0.5, rely=0.5, anchor="center")
        icon = self.thumb(str(ASSETS / "icon.png"), "gate", 64)
        if icon:
            tk.Label(card, image=icon, bg=CARD).pack()
        tk.Label(card, text=f"VELVET  {VERSION}", bg=CARD, fg=GOLD, font=("Segoe UI", 9, "bold")).pack()
        tk.Label(card, text="Аккаунт", bg=CARD, fg=TEXT, font=("Georgia", 26)).pack()
        tk.Label(card, text="Ник уникален. Почта подтверждается кодом, возраст — один раз.", bg=CARD, fg=MUTED, font=("Segoe UI", 10)).pack()
        nb = ttk.Notebook(card)
        nb.pack(fill="both", pady=12)
        login, reg, code = tk.Frame(nb, bg=CARD, padx=8, pady=8), tk.Frame(nb, bg=CARD, padx=8, pady=8), tk.Frame(nb, bg=CARD, padx=8, pady=8)
        nb.add(login, text="Вход")
        nb.add(reg, text="Регистрация")
        nb.add(code, text="Код из письма")
        self._login_form(login)
        self._register_form(reg)
        self._code_form(code)
        tk.Label(wrap, textvariable=self.status, bg=BG, fg=FAINT, font=("Segoe UI", 9)).pack(side="bottom", pady=8)

    def _field(self, parent: tk.Widget, label: str, secret: bool = False) -> tk.Entry:
        tk.Label(parent, text=label, bg=CARD, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w")
        entry = tk.Entry(parent, bg=BG, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11), show="•" if secret else "")
        entry.pack(fill="x", ipady=6, pady=(2, 8))
        return entry

    def _login_form(self, parent: tk.Frame) -> None:
        user = self._field(parent, "Ник")
        password = self._field(parent, "Пароль", secret=True)
        def submit() -> None:
            name = self._find_nick(user.get().strip())
            account = self.store["users"].get(name)
            if not account or account.get("password") != hash_password(password.get(), account.get("salt", "")):
                messagebox.showerror("Velvet", "Неверный ник или пароль")
                return
            if not account.get("email_ok"):
                messagebox.showinfo("Velvet", "Сначала подтвердите почту кодом из письма.")
                return
            self.store["session"] = {"username": name}
            account["username"] = name
            self.user = account
            self.save_store()
            self.show_main()
        self._button(parent, "Войти", submit, primary=True).pack(anchor="e")

    def _register_form(self, parent: tk.Frame) -> None:
        user = self._field(parent, "Ник")
        display = self._field(parent, "Отображаемое имя")
        email = self._field(parent, "Почта")
        password = self._field(parent, "Пароль", secret=True)
        key = self._field(parent, "Ключ администратора, если есть")
        tk.Label(parent, text="Аватар", bg=CARD, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w")
        picks = tk.Frame(parent, bg=CARD)
        picks.pack(fill="x", pady=(2, 8))
        chosen = {"path": str(ASSETS / "avatars" / "preset_1.png")}
        def select(path: str, mark: tk.Label) -> None:
            chosen["path"] = path
            for child in picks.winfo_children():
                if isinstance(child, tk.Label):
                    child.configure(highlightthickness=1, highlightbackground=LINE)
            mark.configure(highlightthickness=2, highlightbackground=ROSE)
        for preset in sorted((ASSETS / "avatars").glob("preset_*.png")):
            img = self.thumb(str(preset), preset.stem, 42)
            if not img:
                continue
            lbl = tk.Label(picks, image=img, bg=CARD, highlightthickness=1, highlightbackground=LINE, cursor="hand2")
            lbl.pack(side="left", padx=3)
            lbl.bind("<Button-1>", lambda _e, p=str(preset), m=lbl: select(p, m))
        self._button(picks, "Свой файл", lambda: self._pick_avatar(chosen)).pack(side="left", padx=6)
        age = tk.BooleanVar(value=False)
        tk.Checkbutton(parent, text="Мне есть 18 лет", variable=age, bg=CARD, fg=TEXT, selectcolor=BG, activebackground=CARD, activeforeground=TEXT).pack(anchor="w")
        def submit() -> None:
            nick = user.get().strip()
            mail = email.get().strip().casefold()
            if len(nick) < 3 or any(ch in nick for ch in " /\\"):
                messagebox.showwarning("Velvet", "Ник — от 3 символов, без пробелов")
                return
            if self._find_nick(nick):
                messagebox.showwarning("Velvet", "Такой ник уже занят")
                return
            if not EMAIL_RE.match(mail) or self._find_email(mail):
                messagebox.showwarning("Velvet", "Нужна свободная почта вида name@mail.com")
                return
            if len(password.get()) < 4 or not age.get():
                messagebox.showwarning("Velvet", "Пароль от 4 символов и отметка 18+")
                return
            code = f"{uuid.uuid4().int % 1000000:06d}"
            self.store["pending"][nick_key(nick)] = {
                "username": nick,
                "display_name": display.get().strip() or nick,
                "email": mail,
                "password": hash_password(password.get(), nick_key(nick)),
                "salt": nick_key(nick),
                "avatar": chosen["path"],
                "is_admin": key.get().strip() == ADMIN_KEY,
                "code": code,
                "created": now(),
            }
            self._deliver_code(mail, nick, code)
            self.save_store()
            self.status.set(f"Код отправлен на {mail}. Откройте вкладку «Код из письма».")
            messagebox.showinfo("Velvet", "Аккаунт ещё не активен. Введите код из письма.")
        self._button(parent, "Создать и отправить код", submit, primary=True).pack(anchor="e", pady=8)

    def _code_form(self, parent: tk.Frame) -> None:
        nick = self._field(parent, "Ник")
        code = self._field(parent, "Код из письма")
        def open_letter() -> None:
            pending = self.store["pending"].get(nick_key(nick.get().strip()))
            if not pending:
                messagebox.showinfo("Velvet", "Нет ожидающей регистрации с этим ником")
                return
            letters = self.store["mailbox"].get(pending["email"], [])
            text = letters[-1]["body"] if letters else "Письма нет"
            messagebox.showinfo("Письмо Velvet", text)
        def submit() -> None:
            key = nick_key(nick.get().strip())
            pending = self.store["pending"].get(key)
            if not pending or code.get().strip() != pending.get("code"):
                messagebox.showerror("Velvet", "Неверный код или ник")
                return
            avatar = self._store_avatar(pending["username"], pending["avatar"])
            account = {
                "password": pending["password"],
                "salt": pending["salt"],
                "display_name": pending["display_name"],
                "email": pending["email"],
                "email_ok": True,
                "avatar": avatar,
                "is_admin": pending["is_admin"],
                "age_ok": True,
                "created": now(),
                "games": [],
                "playtime": {},
                "achievements": [],
                "wishlist": [],
            }
            self.store["users"][pending["username"]] = account
            self.store["pending"].pop(key, None)
            self.store["session"] = {"username": pending["username"]}
            account["username"] = pending["username"]
            self.user = account
            self.save_store()
            self.unlock("hello")
            if "preset_" not in Path(avatar).name:
                self.unlock("face", quiet=True)
            self.show_main()
        self._button(parent, "Открыть письмо", open_letter).pack(anchor="w", pady=(0, 8))
        self._button(parent, "Подтвердить почту", submit, primary=True).pack(anchor="e")

    def _pick_avatar(self, chosen: dict) -> None:
        picked = filedialog.askopenfilename(title="Аватар", filetypes=[("Картинки", "*.png *.gif"), ("Все файлы", "*.*")])
        if picked:
            chosen["path"] = picked

    def _find_nick(self, nick: str) -> str:
        key = nick_key(nick)
        for name in self.store["users"]:
            if nick_key(name) == key:
                return name
        return ""

    def _find_email(self, mail: str) -> bool:
        mail = mail.casefold()
        for account in self.store["users"].values():
            if account.get("email", "").casefold() == mail:
                return True
        return any(item.get("email") == mail for item in self.store["pending"].values())

    def _deliver_code(self, mail: str, nick: str, code: str) -> None:
        body = f"Velvet {VERSION}\nНик: {nick}\nКод подтверждения: {code}\nВведите его во вкладке «Код из письма». Возраст после этого больше не спрашивается."
        self.store["mailbox"].setdefault(mail, []).append({"at": now(), "subject": "Код Velvet", "body": body})
        smtp = self.store.get("settings", {}).get("smtp") or {}
        if smtp.get("host") and smtp.get("from"):
            try:
                msg = EmailMessage()
                msg["Subject"] = "Код Velvet"
                msg["From"] = smtp["from"]
                msg["To"] = mail
                msg.set_content(body)
                with smtplib.SMTP(smtp["host"], int(smtp.get("port") or 587), timeout=20) as server:
                    server.starttls()
                    if smtp.get("user"):
                        server.login(smtp["user"], smtp.get("password", ""))
                    server.send_message(msg)
            except (OSError, smtplib.SMTPException):
                pass

    def _store_avatar(self, username: str, source: str) -> str:
        src = Path(source)
        if not src.exists():
            return str(ASSETS / "avatars" / "preset_1.png")
        dest = AVATARS / f"{username}{src.suffix.lower() or '.png'}"
        if src.resolve() != dest.resolve():
            shutil.copyfile(src, dest)
        return str(dest)

    def show_main(self) -> None:
        self.clear()
        body = tk.Frame(self.shell, bg=BG)
        body.pack(fill="both", expand=True)
        side = tk.Frame(body, bg=BG2, width=232)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        avatar = self.thumb(self.user.get("avatar", ""), "me", 72)
        if avatar:
            tk.Label(side, image=avatar, bg=BG2).pack(anchor="w", padx=18, pady=(16, 4))
        tk.Label(side, text=self.user.get("display_name") or self.user["username"], bg=BG2, fg=TEXT, font=("Georgia", 16)).pack(anchor="w", padx=18)
        role = "админ" if self.user.get("is_admin") else "игрок"
        tk.Label(side, text=f"@{self.user['username']} · {role}", bg=BG2, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w", padx=18)
        self.hours_label = tk.Label(side, text=self._hours_line(), bg=BG2, fg=GOLD, font=("Segoe UI", 9))
        self.hours_label.pack(anchor="w", padx=18, pady=(2, 12))
        self.nav_buttons = {}
        items = [("library", "Библиотека"), ("downloads", "Загрузки"), ("catalog", "Каталог"), ("achievements", "Достижения"), ("profile", "Профиль")]
        if self.user.get("is_admin"):
            items.append(("admin", "Админ"))
        for key, label in items:
            btn = tk.Button(side, text=label, anchor="w", relief="flat", bd=0, bg=BG2, fg=MUTED, activebackground="#241c2c", activeforeground=TEXT, font=("Segoe UI", 11), padx=16, pady=8, cursor="hand2", command=lambda k=key: self.switch(k))
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[key] = btn
        self._button(side, "Выйти", self.logout).pack(side="bottom", anchor="w", padx=16, pady=16)
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        self.content = tk.Frame(right, bg=BG)
        self.content.pack(fill="both", expand=True, padx=22, pady=16)
        tk.Label(right, textvariable=self.status, bg=BG, fg=FAINT, font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=22, pady=(0, 8))
        self.switch("library")
        self.after(900, self.check_updates)

    def _hours_line(self) -> str:
        total = sum(int(v) for v in (self.user.get("playtime") or {}).values())
        return f"Наиграно {fmt_time(total)}"

    def logout(self) -> None:
        self.save_store()
        self.store["session"] = {}
        self.save_store()
        self.user = None
        self.show_auth()

    def switch(self, view: str) -> None:
        self.view = view
        for key, btn in self.nav_buttons.items():
            btn.configure(bg="#2a2030" if key == view else BG2, fg=TEXT if key == view else MUTED)
        for child in self.content.winfo_children():
            child.destroy()
        {"library": self.render_library, "downloads": self.render_downloads, "catalog": self.render_catalog, "achievements": self.render_achievements, "profile": self.render_profile, "admin": self.render_admin}[view]()

    def render_library(self) -> None:
        head = tk.Frame(self.content, bg=BG)
        head.pack(fill="x")
        tk.Label(head, text="Библиотека", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(side="left")
        self._button(head, "Добавить игру", self.add_game, primary=True).pack(side="right")
        self._button(head, "Папка игр", lambda: open_folder(str(GAMES))).pack(side="right", padx=8)
        search = tk.Entry(head, textvariable=self.query, bg=CARD, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        search.pack(side="right", padx=8, ipady=6, ipadx=8)
        search.bind("<KeyRelease>", lambda _e: self.fill_games())
        tk.Label(self.content, text="Библиотека показывает всё из папки games. Часы пишутся отдельно на каждую игру.", bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 8))
        chips = tk.Frame(self.content, bg=BG)
        chips.pack(fill="x", pady=(0, 8))
        for tag in ("все", "избранное", "RPG", "новелла", "песочница"):
            on = tag == self.filter
            tk.Button(chips, text=tag, relief="flat", bd=0, cursor="hand2", bg="#3a2030" if on else CARD, fg=TEXT if on else MUTED, font=("Segoe UI", 9), padx=10, pady=4, command=lambda t=tag: self.set_filter(t)).pack(side="left", padx=(0, 6))
        canvas = tk.Canvas(self.content, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(self.content, orient="vertical", command=canvas.yview)
        self.game_box = tk.Frame(canvas, bg=BG)
        self.game_box.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.game_box, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.fill_games()

    def sync_games_folder(self) -> None:
        GAMES.mkdir(exist_ok=True)
        games = self.user.setdefault("games", [])
        known = {str(Path(g.get("folder") or "").resolve()) for g in games if g.get("folder")}
        for child in sorted(GAMES.iterdir(), key=lambda p: p.name.casefold()):
            if child.name.startswith(".") or child.suffix.lower() in {".tmp", ".part"}:
                continue
            folder = child if child.is_dir() else child.parent
            key = str(folder.resolve())
            if key in known:
                continue
            exe = self._find_exe(child)
            games.append({
                "id": uuid.uuid4().hex[:10],
                "title": child.stem if child.is_file() else child.name,
                "developer": "",
                "tags": [],
                "exec_path": str(exe) if exe else "",
                "folder": key,
                "icon": str(self._find_icon(folder) or ""),
                "mod_dir": str(folder / "game") if (folder / "game").is_dir() else "",
                "mods": [],
                "accent": ROSE,
                "favorite": False,
                "added": now(),
            })
            known.add(key)
        self.save_store()

    def _find_exe(self, path: Path) -> Path | None:
        if path.is_file():
            return path
        patterns = ("*.exe", "*.sh", "*.command", "*.AppImage") if sys.platform == "win32" else ("*.exe", "*.sh", "*.AppImage", "*.bin")
        for pattern in patterns:
            found = sorted(path.glob(pattern))
            if found:
                return found[0]
        return None

    def _find_icon(self, folder: Path) -> Path | None:
        names = ("icon.png", "icon.gif", "cover.png", "cover.gif")
        for name in names:
            candidate = folder / name
            if candidate.is_file():
                return candidate
        for candidate in folder.glob("*.png"):
            return candidate
        return None

    def set_filter(self, tag: str) -> None:
        self.filter = tag
        self.switch("library")

    def fill_games(self) -> None:
        if not hasattr(self, "game_box") or not self.game_box.winfo_exists():
            return
        self.sync_games_folder()
        for child in self.game_box.winfo_children():
            child.destroy()
        q = self.query.get().strip().lower()
        games = []
        for game in self.user.get("games", []):
            if q and q not in f"{game.get('title','')} {game.get('developer','')}".lower():
                continue
            if self.filter == "избранное" and not game.get("favorite"):
                continue
            if self.filter not in ("все", "избранное") and self.filter.lower() not in " ".join(game.get("tags") or []).lower():
                continue
            games.append(game)
        if not games:
            tk.Label(self.game_box, text="В папке games пока пусто.\nСкачайте игру в разделе «Загрузки» или положите сборку в эту папку.", bg=BG, fg=MUTED, font=("Segoe UI", 12), justify="left").pack(anchor="w", pady=20)
            return
        for game in games:
            self._game_card(game).pack(fill="x", pady=6)

    def _game_card(self, game: dict) -> tk.Frame:
        card = tk.Frame(self.game_box, bg=CARD, highlightbackground=LINE, highlightthickness=1, padx=12, pady=10)
        icon = self.thumb(game.get("icon") or "", f"game-{game['id']}", 64)
        if icon:
            tk.Label(card, image=icon, bg=CARD).pack(side="left", padx=(0, 10))
        else:
            badge = tk.Label(card, text=(game.get("title") or "?")[:1].upper(), bg=ROSE, fg="white", font=("Georgia", 18), width=3, height=2)
            badge.pack(side="left", padx=(0, 10))
        info = tk.Frame(card, bg=CARD)
        info.pack(side="left", fill="both", expand=True)
        tk.Label(info, text=game.get("title") or "Без названия", bg=CARD, fg=TEXT, font=("Segoe UI", 13, "bold")).pack(anchor="w")
        played = int((self.user.get("playtime") or {}).get(game["id"], 0))
        mods = len(game.get("mods") or [])
        tk.Label(info, text=f"В этой игре {fmt_time(played)}   ·   модов {mods}", bg=CARD, fg=GOLD, font=("Segoe UI", 9)).pack(anchor="w")
        actions = tk.Frame(card, bg=CARD)
        actions.pack(side="right")
        gid = game["id"]
        self._button(actions, "Играть", lambda g=gid: self.play(g), primary=True).pack(side="left")
        self._button(actions, "Иконка", lambda g=gid: self.pick_icon(g)).pack(side="left", padx=4)
        self._button(actions, "Моды", lambda g=gid: self.mods(g)).pack(side="left", padx=4)
        self._button(actions, "Сейвы", lambda g=gid: self.saves(g)).pack(side="left")
        self._button(actions, "★" if game.get("favorite") else "☆", lambda g=gid: self.favorite(g)).pack(side="left", padx=4)
        self._button(actions, "Убрать", lambda g=gid: self.remove(g)).pack(side="left")
        return card

    def add_game(self) -> None:
        dialog = tk.Toplevel(self)
        dialog.title("Добавить игру")
        dialog.configure(bg=CARD)
        dialog.geometry("540x460")
        dialog.transient(self)
        dialog.grab_set()
        fields = {}
        for label, key in (("Название", "title"), ("Автор", "developer"), ("Теги через запятую", "tags"), ("Папка модов, если игра их читает", "mod_dir")):
            tk.Label(dialog, text=label, bg=CARD, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w", padx=18, pady=(8, 2))
            entry = tk.Entry(dialog, bg=BG, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
            entry.pack(fill="x", padx=18, ipady=5)
            fields[key] = entry
        tk.Label(dialog, text="Файл запуска", bg=CARD, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w", padx=18, pady=(8, 2))
        path_row = tk.Frame(dialog, bg=CARD)
        path_row.pack(fill="x", padx=18)
        path_entry = tk.Entry(path_row, bg=BG, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        path_entry.pack(side="left", fill="x", expand=True, ipady=5)
        fields["exec_path"] = path_entry
        def browse() -> None:
            types = [("Программы", "*.exe"), ("Все файлы", "*.*")] if sys.platform == "win32" else [("Все файлы", "*.*")]
            picked = filedialog.askopenfilename(parent=dialog, title="Файл запуска", filetypes=types)
            if picked:
                path_entry.delete(0, "end")
                path_entry.insert(0, picked)
                if not fields["title"].get().strip():
                    fields["title"].insert(0, Path(picked).stem)
                game_dir = Path(picked).parent / "game"
                if game_dir.is_dir() and not fields["mod_dir"].get().strip():
                    fields["mod_dir"].insert(0, str(game_dir))
        self._button(path_row, "Обзор", browse).pack(side="left", padx=(8, 0))
        def save() -> None:
            title = fields["title"].get().strip()
            if not title:
                messagebox.showwarning("Velvet", "Нужно название", parent=dialog)
                return
            self.user.setdefault("games", []).append({
                "id": uuid.uuid4().hex[:10], "title": title, "developer": fields["developer"].get().strip(),
                "tags": [t.strip() for t in fields["tags"].get().split(",") if t.strip()][:8],
                "exec_path": fields["exec_path"].get().strip(), "mod_dir": fields["mod_dir"].get().strip(),
                "mods": [], "accent": ROSE, "favorite": False, "added": now(),
            })
            self.save_store()
            self.unlock_library()
            self.unlock_titles()
            dialog.destroy()
            self.switch("library")
        self._button(dialog, "Сохранить", save, primary=True).pack(anchor="e", padx=18, pady=16)

    def _find(self, gid: str) -> dict | None:
        return next((g for g in self.user.get("games", []) if g.get("id") == gid), None)

    def play(self, gid: str) -> None:
        game = self._find(gid)
        if not game or not game.get("exec_path"):
            messagebox.showinfo("Velvet", "Укажите файл запуска.")
            return
        try:
            proc = launch_path(game["exec_path"])
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Velvet", str(exc))
            return
        self.unlock("first")
        self.status.set(f"Сессия: {game['title']}")
        threading.Thread(target=self._watch, args=(gid, game["title"], proc, time.time()), daemon=True).start()

    def _watch(self, gid: str, title: str, proc: subprocess.Popen, started: float) -> None:
        proc.wait()
        self.after(0, lambda: self._commit_time(gid, title, max(1, int(time.time() - started))))

    def _commit_time(self, gid: str, title: str, elapsed: int) -> None:
        if not self.user:
            return
        play = self.user.setdefault("playtime", {})
        play[gid] = int(play.get(gid, 0)) + elapsed
        self.save_store()
        self.unlock_time()
        self.unlock_titles()
        self.status.set(f"«{title}»: +{fmt_time(elapsed)}")
        if hasattr(self, "hours_label") and self.hours_label.winfo_exists():
            self.hours_label.configure(text=self._hours_line())
        if self.view == "library":
            self.fill_games()

    def pick_icon(self, gid: str) -> None:
        game = self._find(gid)
        if not game:
            return
        picked = filedialog.askopenfilename(title="Иконка игры", filetypes=[("Картинки", "*.png *.gif"), ("Все файлы", "*.*")])
        if not picked:
            return
        ICONS.mkdir(exist_ok=True)
        dest = ICONS / f"{gid}{Path(picked).suffix.lower() or '.png'}"
        shutil.copyfile(picked, dest)
        game["icon"] = str(dest)
        self.images.pop(f"game-{gid}-64", None)
        self.save_store()
        self.fill_games()

    def favorite(self, gid: str) -> None:
        game = self._find(gid)
        if not game:
            return
        game["favorite"] = not game.get("favorite")
        self.save_store()
        self.fill_games()

    def remove(self, gid: str) -> None:
        game = self._find(gid)
        if not game or not messagebox.askyesno("Velvet", f"Убрать «{game.get('title')}»? Файлы игры не удаляются."):
            return
        self.user["games"] = [g for g in self.user["games"] if g.get("id") != gid]
        self.save_store()
        self.fill_games()

    def mods(self, gid: str) -> None:
        game = self._find(gid)
        if not game:
            return
        if not game.get("mod_dir"):
            messagebox.showinfo("Velvet", "У этой игры не указана папка модов. Добавьте игру заново или впишите папку, откуда она читает моды. Hornycraft обычно берёт скрипты из папки game.")
        dialog = tk.Toplevel(self)
        dialog.title(f"Моды — {game['title']}")
        dialog.configure(bg=BG)
        dialog.geometry("640x460")
        box = tk.Frame(dialog, bg=BG)
        box.pack(fill="both", expand=True, padx=12, pady=12)
        def redraw() -> None:
            for child in box.winfo_children():
                child.destroy()
            tk.Label(box, text=game.get("mod_dir") or "Папка модов не задана — файлы хранятся в лаунчере", bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")
            for mod in game.get("mods") or []:
                row = tk.Frame(box, bg=CARD, padx=10, pady=8)
                row.pack(fill="x", pady=4)
                state = "включён" if mod.get("enabled") else "выключен"
                tk.Label(row, text=f"{mod['name']} · {state}", bg=CARD, fg=TEXT).pack(side="left")
                self._button(row, "Вкл/выкл", lambda m=mod: toggle(m)).pack(side="right")
            self._button(box, "Добавить файл мода", add, primary=True).pack(anchor="w", pady=10)
        def toggle(mod: dict) -> None:
            mod["enabled"] = not mod.get("enabled")
            self._sync_mod(game, mod)
            self.save_store()
            redraw()
        def add() -> None:
            picked = filedialog.askopenfilename(parent=dialog, title="Файл мода", filetypes=[("Мод", "*.rpy *.rpyc *.zip *.json *.png"), ("Все файлы", "*.*")])
            if not picked:
                return
            dest_dir = MODS / self.user["username"] / game["id"]
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / Path(picked).name
            shutil.copyfile(picked, dest)
            mod = {"id": uuid.uuid4().hex[:8], "name": dest.name, "path": str(dest), "enabled": True}
            game.setdefault("mods", []).append(mod)
            self._sync_mod(game, mod)
            self.save_store()
            self.unlock("modder")
            redraw()
        redraw()

    def _sync_mod(self, game: dict, mod: dict) -> None:
        folder = game.get("mod_dir")
        if not folder:
            return
        target = Path(folder)
        target.mkdir(parents=True, exist_ok=True)
        dest = target / Path(mod["path"]).name
        if mod.get("enabled"):
            if Path(mod["path"]).exists():
                shutil.copyfile(mod["path"], dest)
        elif dest.exists():
            dest.unlink()

    def saves(self, gid: str) -> None:
        game = self._find(gid)
        if not game:
            return
        self.unlock("archivist")
        dialog = tk.Toplevel(self)
        dialog.title(f"Редактор сохранений — {game['title']}")
        dialog.configure(bg=BG)
        dialog.geometry("760x560")
        folders = []
        if game.get("exec_path"):
            folders.append(Path(game["exec_path"]).parent)
        found = renpy_save_dir(game["title"])
        if found:
            folders.append(found)
        tk.Label(dialog, text="Перед записью копия кладётся в data/save-backups. Бинарные сейвы можно только копировать.", bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=8)
        listing = tk.Listbox(dialog, bg=CARD, fg=TEXT, font=("Segoe UI", 10), height=8)
        listing.pack(fill="x", padx=12)
        files: list[Path] = []
        for folder in folders:
            if folder.exists():
                files.extend([p for p in folder.rglob("*") if p.is_file() and p.stat().st_size < 8_000_000][:40])
        for file in files:
            listing.insert("end", str(file))
        editor = tk.Text(dialog, bg=CARD, fg=TEXT, insertbackground=TEXT, font=("Consolas", 10), height=16)
        editor.pack(fill="both", expand=True, padx=12, pady=8)
        current = {"path": None, "member": None}

        def open_selected() -> None:
            if not listing.curselection():
                return
            path = Path(listing.get(listing.curselection()[0]))
            current["path"] = path
            current["member"] = None
            editor.delete("1.0", "end")
            if zipfile.is_zipfile(path):
                with zipfile.ZipFile(path) as zf:
                    names = [n for n in zf.namelist() if n.endswith((".json", ".txt", ".rpy"))]
                    current["member"] = names[0] if names else None
                    if current["member"]:
                        editor.insert("1.0", zf.read(current["member"]).decode("utf-8", "replace"))
                    else:
                        editor.insert("1.0", "В архиве нет текстового файла. Слот можно только копировать.")
                return
            raw = path.read_bytes()
            try:
                editor.insert("1.0", raw.decode("utf-8"))
            except UnicodeDecodeError:
                editor.insert("1.0", "Бинарное сохранение. Редактирование отключено, чтобы не сломать слот.")
                editor.configure(state="disabled")

        def write_back() -> None:
            path = current["path"]
            if not path:
                return
            text = editor.get("1.0", "end-1c")
            stamp = time.strftime("%Y%m%d-%H%M%S")
            backup = SAVE_BACKUPS / f"{path.name}-{stamp}"
            shutil.copyfile(path, backup)
            if current["member"] and zipfile.is_zipfile(path):
                temp = path.with_suffix(path.suffix + ".tmp")
                with zipfile.ZipFile(path, "r") as src, zipfile.ZipFile(temp, "w") as dst:
                    for info in src.infolist():
                        data = text.encode("utf-8") if info.filename == current["member"] else src.read(info.filename)
                        dst.writestr(info, data)
                temp.replace(path)
            else:
                path.write_text(text, encoding="utf-8")
            self.save_store()
            messagebox.showinfo("Velvet", f"Записано. Копия: {backup.name}", parent=dialog)

        row = tk.Frame(dialog, bg=BG)
        row.pack(fill="x", padx=12, pady=(0, 12))
        self._button(row, "Открыть", open_selected, primary=True).pack(side="left")
        self._button(row, "Записать", write_back).pack(side="left", padx=8)
        self._button(row, "Папка сейвов", lambda: open_folder(str(files[0].parent)) if files else None).pack(side="left")

    def render_downloads(self) -> None:
        tk.Label(self.content, text="Загрузки", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(anchor="w")
        tk.Label(self.content, text="Игра сохранится в папку games и появится в библиотеке. Архив распакуется сам.", bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 6))
        self.url_entry = tk.Entry(self.content, bg=CARD, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        self.url_entry.pack(fill="x", ipady=7, pady=(2, 6))
        self.game_name = tk.Entry(self.content, bg=CARD, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 11))
        self.game_name.pack(fill="x", ipady=7)
        self.game_name.insert(0, "")
        tk.Label(self.content, text="Название папки в games, если нужно своё", bg=BG, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w")
        row = tk.Frame(self.content, bg=BG)
        row.pack(fill="x", pady=8)
        self._button(row, "Скачать в игры", self.start_download, primary=True).pack(side="left")
        self._button(row, "Папка игр", lambda: open_folder(str(GAMES))).pack(side="left", padx=8)
        self.job_box = tk.Frame(self.content, bg=BG)
        self.job_box.pack(fill="both", expand=True, pady=12)
        self.refresh_jobs()

    def start_download(self) -> None:
        url = self.url_entry.get().strip()
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            messagebox.showwarning("Velvet", "Нужна прямая http(s) ссылка.")
            return
        name = re.sub(r"[^\w.\- ]+", "_", self.game_name.get().strip() or Path(parsed.path).stem or "game")
        folder = GAMES / name
        folder.mkdir(parents=True, exist_ok=True)
        filename = Path(parsed.path).name or "download.bin"
        dest = folder / filename
        if dest.exists():
            dest = folder / f"{dest.stem}-{uuid.uuid4().hex[:4]}{dest.suffix}"
        job_id = uuid.uuid4().hex[:8]
        self.jobs[job_id] = {"name": dest.name, "status": "качается", "bytes": 0, "total": 0, "error": "", "folder": str(folder)}
        threading.Thread(target=self._download, args=(job_id, url, dest, folder), daemon=True).start()
        self.game_name.delete(0, "end")
        self.refresh_jobs()

    def _download(self, job_id: str, url: str, dest: Path, folder: Path) -> None:
        try:
            req = Request(url, headers={"User-Agent": "VelvetLauncher/2.2"})
            with urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("Content-Length") or 0)
                got = 0
                with dest.open("wb") as fh:
                    while True:
                        chunk = resp.read(1024 * 256)
                        if not chunk:
                            break
                        fh.write(chunk)
                        got += len(chunk)
                        self.jobs[job_id]["bytes"] = got
                        self.jobs[job_id]["total"] = total
            if zipfile.is_zipfile(dest):
                with zipfile.ZipFile(dest) as zf:
                    zf.extractall(folder)
            self.jobs[job_id]["status"] = "в библиотеке"
            self.after(0, self.sync_games_folder)
        except (HTTPError, URLError, TimeoutError, OSError, zipfile.BadZipFile) as exc:
            self.jobs[job_id]["status"] = "ошибка"
            self.jobs[job_id]["error"] = str(exc)

    def refresh_jobs(self) -> None:
        if self.view != "downloads" or not hasattr(self, "job_box") or not self.job_box.winfo_exists():
            return
        for child in self.job_box.winfo_children():
            child.destroy()
        if not self.jobs:
            tk.Label(self.job_box, text="Загрузок не было.", bg=BG, fg=MUTED).pack(anchor="w")
        for job in self.jobs.values():
            line = tk.Frame(self.job_box, bg=CARD, padx=12, pady=8)
            line.pack(fill="x", pady=4)
            tk.Label(line, text=f"{job['name']} · {job['status']} · {job['bytes'] / 1048576:.1f} МБ", bg=CARD, fg=TEXT).pack(anchor="w")
        self.after(800, self.refresh_jobs)

    def render_catalog(self) -> None:
        tk.Label(self.content, text="Каталог", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(anchor="w")
        tk.Label(self.content, text="«Установить» открывает веб-витрину. Чужие сборки лаунчер не раздаёт.", bg=BG, fg=MUTED).pack(anchor="w", pady=(4, 10))
        for title, text, url in STORES:
            row = tk.Frame(self.content, bg=CARD, highlightbackground=LINE, highlightthickness=1, padx=14, pady=10)
            row.pack(fill="x", pady=4)
            tk.Label(row, text=title, bg=CARD, fg=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
            self._button(row, "Установить", lambda u=url, t=title: self.open_store(u, t), primary=True).pack(side="right")

    def open_store(self, url: str, title: str) -> None:
        webbrowser.open(url)
        self.unlock("store")
        self.status.set(f"Веб-витрина: {title}")

    def render_achievements(self) -> None:
        tk.Label(self.content, text="Достижения", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(anchor="w")
        got = {item["id"]: item for item in self.user.get("achievements", [])}
        tk.Label(self.content, text=f"Открыто {len(got)} из {len(ACHIEVEMENTS)}. Список прокручивается.", bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 10))
        canvas = tk.Canvas(self.content, bg=BG, highlightthickness=0)
        scroll = ttk.Scrollbar(self.content, orient="vertical", command=canvas.yview)
        box = tk.Frame(canvas, bg=BG)
        box.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=box, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        for aid, title, text in ACHIEVEMENTS:
            owned = aid in got
            row = tk.Frame(box, bg=CARD, highlightbackground=GOLD if owned else LINE, highlightthickness=1, padx=12, pady=8)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=title, bg=CARD, fg=GOLD if owned else TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w")
            when = f" · {got[aid]['at']}" if owned else ""
            tk.Label(row, text=text + when, bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w")

    def render_profile(self) -> None:
        tk.Label(self.content, text="Профиль", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(anchor="w")
        avatar = self.thumb(self.user.get("avatar", ""), "profile", 84)
        if avatar:
            tk.Label(self.content, image=avatar, bg=BG).pack(anchor="w", pady=6)
        tk.Label(self.content, text=f"{self.user.get('display_name')} · {self.user.get('email')}", bg=BG, fg=TEXT, font=("Segoe UI", 12)).pack(anchor="w")
        tk.Label(self.content, text=self._hours_line(), bg=BG, fg=GOLD).pack(anchor="w", pady=(2, 8))
        tk.Label(self.content, text="Сейф хранит копию всех данных в data/backups. Это не облако: файл лежит рядом с программой.", bg=BG, fg=MUTED, wraplength=720, justify="left").pack(anchor="w")
        def export_safe() -> None:
            self.save_store()
            self.backup()
            self.unlock("safe")
            messagebox.showinfo("Сейф", f"Копия записана в {BACKUPS}")
        def new_avatar() -> None:
            picked = filedialog.askopenfilename(title="Аватар", filetypes=[("Картинки", "*.png *.gif")])
            if picked:
                self.user["avatar"] = self._store_avatar(self.user["username"], picked)
                self.save_store()
                self.unlock("face")
                self.show_main()
        row = tk.Frame(self.content, bg=BG)
        row.pack(anchor="w", pady=10)
        self._button(row, "Сменить аватар", new_avatar, primary=True).pack(side="left")
        self._button(row, "Сохранить в сейф", export_safe).pack(side="left", padx=8)
        self._button(row, "Проверить обновление", lambda: self.check_updates(True)).pack(side="left")
        tk.Label(self.content, text=f"Сейчас установлена {VERSION}. Если на сайте версия новее, лаунчер скачает её сам и не тронет папку data.", bg=BG, fg=FAINT, font=("Segoe UI", 9), wraplength=720, justify="left").pack(anchor="w", pady=(8, 0))

    def render_admin(self) -> None:
        tk.Label(self.content, text="Админ", bg=BG, fg=TEXT, font=("Georgia", 26)).pack(anchor="w")
        tk.Label(self.content, text="SMTP необязателен. Без него код всё равно есть во встроенном письме.", bg=BG, fg=MUTED).pack(anchor="w", pady=(4, 8))
        host = self._field_line("SMTP host")
        sender = self._field_line("От кого")
        smtp_user = self._field_line("Логин SMTP")
        smtp_pass = self._field_line("Пароль SMTP", secret=True)
        current = self.store.get("settings", {}).get("smtp") or {}
        host.insert(0, current.get("host", ""))
        sender.insert(0, current.get("from", ""))
        smtp_user.insert(0, current.get("user", ""))
        def save_smtp() -> None:
            self.store.setdefault("settings", {})["smtp"] = {"host": host.get().strip(), "port": 587, "from": sender.get().strip(), "user": smtp_user.get().strip(), "password": smtp_pass.get()}
            self.save_store()
            self.status.set("SMTP сохранён")
        self._button(self.content, "Сохранить SMTP", save_smtp, primary=True).pack(anchor="w", pady=8)
        for name, account in self.store["users"].items():
            total = sum(int(v) for v in (account.get("playtime") or {}).values())
            tk.Label(self.content, text=f"@{name} · {account.get('email')} · {fmt_time(total)}", bg=BG, fg=TEXT).pack(anchor="w")

    def _field_line(self, label: str, secret: bool = False) -> tk.Entry:
        tk.Label(self.content, text=label, bg=BG, fg=FAINT, font=("Segoe UI", 9)).pack(anchor="w")
        entry = tk.Entry(self.content, bg=CARD, fg=TEXT, insertbackground=TEXT, relief="flat", show="•" if secret else "")
        entry.pack(fill="x", ipady=5, pady=(2, 6))
        return entry

    def check_updates(self, manual: bool = False) -> None:
        url = (self.store.get("settings", {}).get("update_url") or update_url()).strip()
        if not url:
            if manual:
                messagebox.showinfo("Velvet", "В update_url.txt нет адреса version.json. Его даёт сайт лаунчера после публикации.")
            return
        def work() -> None:
            try:
                release = fetch_release(url)
            except (HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
                if manual:
                    self.after(0, lambda: messagebox.showwarning("Velvet", f"Не удалось проверить обновление:\n{exc}"))
                return
            self.after(0, lambda: self._offer_update(release, manual))
        threading.Thread(target=work, daemon=True).start()

    def _offer_update(self, release: dict, manual: bool) -> None:
        remote = str(release.get("version") or "")
        if version_key(remote) <= version_key(VERSION):
            self.status.set(f"Velvet {VERSION} — это последняя версия")
            if manual:
                messagebox.showinfo("Velvet", f"Установлена последняя версия {VERSION}")
            return
        self.status.set(f"Доступна версия {remote}")
        notes = release.get("notes") or "На сайте есть новая сборка."
        if not messagebox.askyesno("Обновление Velvet", f"Вышла {remote}.\nСейчас у вас {VERSION}.\n\n{notes}\n\nСкачать и установить? Папка data не сотрётся."):
            return
        self.status.set(f"Скачиваю {remote}…")
        threading.Thread(target=self._install_update, args=(release,), daemon=True).start()

    def _install_update(self, release: dict) -> None:
        try:
            url = self._package_url(release)
            dest = DATA / "updates" / "velvet-update.zip"
            dest.parent.mkdir(parents=True, exist_ok=True)
            req = Request(url, headers={"User-Agent": f"VelvetLauncher/{VERSION}"})
            with urlopen(req, timeout=120) as resp, dest.open("wb") as fh:
                while True:
                    chunk = resp.read(1024 * 256)
                    if not chunk:
                        break
                    fh.write(chunk)
            unpack = DATA / "updates" / "unpack"
            if unpack.exists():
                shutil.rmtree(unpack)
            with zipfile.ZipFile(dest) as zf:
                zf.extractall(unpack)
            source = next(p.parent for p in unpack.rglob("Velvet.pyw"))
            keep = {"data", "downloads"}
            for item in source.iterdir():
                if item.name in keep or item.name == "update_url.txt":
                    continue
                target = ROOT / item.name
                if item.is_dir():
                    if target.exists():
                        shutil.rmtree(target)
                    shutil.copytree(item, target)
                else:
                    shutil.copy2(item, target)
        except Exception as exc:  # noqa: BLE001
            self.after(0, lambda: messagebox.showerror("Velvet", f"Обновление не установилось:\n{exc}"))
            return
        self.after(0, self._restart_after_update)

    def _package_url(self, release: dict) -> str:
        downloads = release.get("downloads") or {}
        key = "windows" if sys.platform == "win32" else "macos" if sys.platform == "darwin" else "linux"
        link = downloads.get(key) or downloads.get("windows")
        if not link:
            raise ValueError("В манифесте нет сборки для этой системы")
        base = (self.store.get("settings", {}).get("update_url") or update_url()).strip()
        return urljoin(base, link)

    def _restart_after_update(self) -> None:
        messagebox.showinfo("Velvet", "Обновление установлено. Лаунчер сейчас перезапустится. Аккаунт на месте.")
        starter = ROOT / ("start.bat" if sys.platform == "win32" else "start.command" if sys.platform == "darwin" else "start.sh")
        if sys.platform == "win32":
            subprocess.Popen(["cmd", "/c", "start", "", str(starter)], cwd=str(ROOT))
        else:
            subprocess.Popen(["bash", str(starter)], cwd=str(ROOT), start_new_session=True)
        self.destroy()

    def unlock(self, aid: str, quiet: bool = False) -> None:
        if not self.user:
            return
        owned = self.user.setdefault("achievements", [])
        if any(item.get("id") == aid for item in owned):
            return
        title = next((t for i, t, _d in ACHIEVEMENTS if i == aid), aid)
        owned.append({"id": aid, "at": now()})
        self.save_store()
        self.status.set(f"Достижение: {title}")
        if not quiet:
            messagebox.showinfo("Достижение", title)

    def unlock_library(self) -> None:
        count = len(self.user.get("games") or [])
        if count >= 3:
            self.unlock("shelf", quiet=True)
        if count >= 5:
            self.unlock("collector", quiet=True)

    def unlock_time(self) -> None:
        play = self.user.get("playtime") or {}
        if any(int(v) >= 2 * 3600 for v in play.values()):
            self.unlock("marathon", quiet=True)
        if sum(int(v) for v in play.values()) >= 10 * 3600:
            self.unlock("gamer")

    def unlock_titles(self) -> None:
        for game in self.user.get("games") or []:
            title = game.get("title", "").casefold()
            played = int((self.user.get("playtime") or {}).get(game["id"], 0))
            for _key, needle, start_id, hour_id, need in GAME_MARKS:
                if needle in title or (needle == "lonarpg" and "lona" in title):
                    self.unlock(start_id, quiet=True)
                    if played >= need:
                        self.unlock(hour_id)

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False) -> tk.Button:
        return tk.Button(parent, text=text, command=command, cursor="hand2", relief="flat", bd=0, bg=ROSE if primary else "#2a2433", fg="white" if primary else TEXT, activebackground="#d01858" if primary else "#3a3344", activeforeground="white", font=("Segoe UI", 10), padx=12, pady=7)


def main() -> None:
    App().mainloop()


if __name__ == "__main__":
    main()
